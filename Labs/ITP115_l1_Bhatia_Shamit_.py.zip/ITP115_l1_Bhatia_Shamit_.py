# Shamit Bhatia
# ITP 115, Spring 2016
# Lab practical L1
# Shamitbh@usc.edu

print (" ____\n\n|    |\n\n|    |\n\n|____|")


print("\n\n\n")


print ("You don't frighten us, English pig-dogs!\n\nGo and boil your bottoms, sons of a silly person!\n\n\t\t-\"Monty Python and the Holy Grail\"")

month = input("What month are we in?: ")

date = input ("What is today's date: ")

dayOfMonth = int(input("What day of the month is today: "))

print ("Today is",date,month,dayOfMonth,"and Tomorrow will be",month,dayOfMonth+1)