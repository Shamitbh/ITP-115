# Shamit Bhatia
# ITP 115, Fall 2016
# Lab practical L10
# Shamitbh@usc.edu


def main():

    letterFreq = {}

    fileIn = open("gettysburg.txt","r")



    for line in fileIn:
        line = line.strip()
        line = line.lower()
        line = line.replace(",","")
        line = line.replace(".","")
        line = line.replace(" ","")
        line = line.replace("-","")
        for letter in line:
            if letter not in letterFreq:
                letterFreq[letter] = 1
            else:
                letterFreq[letter] = letterFreq[letter] + 1
    fileIn.close()

    sortedKeys = list(letterFreq.keys())
    sortedKeys.sort()

    for letter in sortedKeys:
        print(letter, "\t", letterFreq[letter])



main()