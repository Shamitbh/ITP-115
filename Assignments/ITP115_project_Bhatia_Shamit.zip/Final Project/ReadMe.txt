Name: Shamit Bhatia
Email: Shamitbh@usc.edu
ITP 115, Fall 2016
Final Project

Program Name: Scrabbler

-The program is run by running the Main.py file.
 Everything after that involves user input.
-The program displays a menu of 8 options to the user.
 The user can choose from these options to gain information
 about words in the English language.
-The only resource I used was stack overflow, in which I searched
 up how to sort a string, as well as the startswith method.
-Overall, the project took 5-10 hours to complete, taking in time
 for writing pseudocode as well as logic.

